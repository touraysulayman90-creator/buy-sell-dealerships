BUY & SELL DEALERSHIPS WEBSITE

To preview:
- Open index.html in a browser.

To publish free with Netlify:
1. Open https://app.netlify.com/drop
2. Upload/drag the unzipped "buy_sell_dealerships" folder.
3. Netlify will provide a public URL ending in netlify.app.
4. You can rename the site from the Netlify dashboard.

WhatsApp contact is set to +220 866898871.
The vehicle inventory is intentionally empty until real listings and prices are provided.
The photos are loaded from Unsplash and therefore require an internet connection.
